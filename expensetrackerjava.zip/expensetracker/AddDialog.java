package com.example.expensetracker;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;

public class AddDialog extends Dialog {

    private final boolean isIncome;
    private final Runnable onSave;

    public AddDialog(Context context, boolean isIncome, Runnable onSave) {
        super(context);
        this.isIncome = isIncome;
        this.onSave = onSave;
    }

    @SuppressLint("MutatingSharedPrefs")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_add_transaction);

        EditText etAmount = findViewById(R.id.etAmount);
        Spinner spinnerCategory = findViewById(R.id.spinnerCategory);
        TextView tvTitle = findViewById(R.id.tvDialogTitle);
        Button btnSave = findViewById(R.id.btnDialogSave);

        tvTitle.setText(isIncome ? "Add Extra Income" : "Add Expense");
        tvTitle.setTextColor(isIncome ? 0xFF00b894 : 0xFFd63031);

        String[] expenseCats = {"Food", "Transport","Bills","Rent","Shopping","Health","Fuel","Internet","Other"};
        String[] incomeCats = {"Gift","Bonus","Freelance","Salary Top-up","Investment","Other"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, isIncome ? incomeCats : expenseCats);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        btnSave.setOnClickListener(v -> {
            String amountStr = etAmount.getText().toString().replaceAll("[^\\d.]", "");
            if (amountStr.isEmpty()) {
                Toast.makeText(getContext(), "Enter amount", Toast.LENGTH_SHORT).show();
                return;
            }
            float amount = Float.parseFloat(amountStr);
            String category = spinnerCategory.getSelectedItem().toString();
            @SuppressLint("SimpleDateFormat") String date = new SimpleDateFormat("dd MMM yyyy").format(new Date());

            SharedPreferences prefs = getContext().getSharedPreferences("ExpenseTracker", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            // Save total
            if (isIncome) {
                float current = prefs.getFloat("extra_income", 0f);
                editor.putFloat("extra_income", current + amount);
            } else {
                float current = prefs.getFloat("total_expense", 0f);
                editor.putFloat("total_expense", current + amount);
            }

            // Save to history
            String entry = (isIncome ? "+" : "-") + amount + "|" + category + "|" + date;
            HashSet<String> history = (HashSet<String>) prefs.getStringSet("history", new HashSet<>());
            history.add(entry);
            editor.putStringSet("history", history);
            editor.apply();

            Toast.makeText(getContext(), (isIncome ? "Income" : "Expense") + " added!", Toast.LENGTH_SHORT).show();
            dismiss();
            onSave.run();
        });
    }
}