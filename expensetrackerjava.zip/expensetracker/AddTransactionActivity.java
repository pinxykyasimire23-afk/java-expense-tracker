package com.example.expensetracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddTransactionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        boolean isIncome = getIntent().getBooleanExtra("isIncome", true);

        TextView tvTitle = findViewById(R.id.tvTitle);
        EditText etAmount = findViewById(R.id.etAmount);
        EditText etNote = findViewById(R.id.etNote);
        Spinner spinner = findViewById(R.id.spinnerCategory);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        tvTitle.setText(isIncome ? "Add Extra Income" : "Add Expense");
        tvTitle.setTextColor(getResources().getColor(isIncome ? android.R.color.holo_green_dark : android.R.color.holo_red_dark));

        String[] expense = {"Food", "Transport", "Shopping", "Bills", "Entertainment", "Health", "Other"};
        String[] income = {"Gift", "Bonus", "Freelance", "Refund", "Investment", "Other"};

        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                isIncome ? income : expense));

        btnSave.setOnClickListener(v -> {
            String amt = etAmount.getText().toString().trim();
            if (amt.isEmpty()) { Toast.makeText(this, "Enter amount!", Toast.LENGTH_SHORT).show(); return; }

            float amount = Float.parseFloat(amt);
            String note = etNote.getText().toString().trim();
            if (note.isEmpty()) note = "No note";
            String cat = spinner.getSelectedItem().toString();
            String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).format(new Date());

            String key = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(new Date()) + "|" + System.currentTimeMillis();
            String value = amount + "|" + note + "|" + isIncome + "|" + cat + "|" + date;

            getSharedPreferences("transactions", MODE_PRIVATE).edit().putString(key, value).apply();
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
            finish();
        });

        btnCancel.setOnClickListener(v -> finish());
    }
}