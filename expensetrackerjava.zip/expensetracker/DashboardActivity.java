
package com.example.expensetracker;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvBalance, tvSalary, tvExpense, tvIncome;
    private FloatingActionButton fabMain, fabIncome, fabExpense;
    private View overlay;
    private SharedPreferences prefs, transPrefs;
    private boolean isFabOpen = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvBalance = findViewById(R.id.tvBalance);
        tvSalary = findViewById(R.id.tvSalary);
        tvExpense = findViewById(R.id.tvExpense);
        tvIncome = findViewById(R.id.tvIncome);
        fabMain = findViewById(R.id.fabMain);
        fabIncome = findViewById(R.id.fabIncome);
        fabExpense = findViewById(R.id.fabExpense);
        overlay = findViewById(R.id.overlay);

        Button btnHistory = findViewById(R.id.btnHistory);
        Button btnClearMonth = findViewById(R.id.btnClearMonth);
        Button btnResetAll = findViewById(R.id.btnResetAll);

        prefs = getSharedPreferences("ExpenseTracker", MODE_PRIVATE);
        transPrefs = getSharedPreferences("transactions", MODE_PRIVATE);

        fabMain.setOnClickListener(v -> toggleFab());
        overlay.setOnClickListener(v -> closeFab());

        fabIncome.setOnClickListener(v -> {
            closeFab();
            startActivity(new Intent(this, AddTransactionActivity.class).putExtra("isIncome", true));
        });

        fabExpense.setOnClickListener(v -> {
            closeFab();
            startActivity(new Intent(this, AddTransactionActivity.class).putExtra("isIncome", false));
        });

        btnHistory.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        btnClearMonth.setOnClickListener(v -> clearThisMonth());
        btnResetAll.setOnClickListener(v -> resetEverything());

        loadAndShowAllData();
    }

    private void toggleFab() {
        if (isFabOpen) {
            closeFab();
            fabMain.animate().rotation(0).setDuration(200).start();
        } else {
            fabIncome.setVisibility(View.VISIBLE);
            fabExpense.setVisibility(View.VISIBLE);
            overlay.setVisibility(View.VISIBLE);
            fabMain.animate().rotation(45).setDuration(200).start();
            isFabOpen = true;
        }
    }

    private void closeFab() {
        fabIncome.setVisibility(View.GONE);
        fabExpense.setVisibility(View.GONE);
        overlay.setVisibility(View.GONE);
        isFabOpen = false;
    }

    private void clearThisMonth() {
        new AlertDialog.Builder(this)
                .setTitle("Clear This Month?")
                .setMessage("Delete all for " + new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(new Date()) + "?")
                .setPositiveButton("Yes", (d, w) -> {
                    String month = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(new Date());
                    SharedPreferences.Editor e = transPrefs.edit();
                    for (String k : transPrefs.getAll().keySet())
                        if (k.startsWith(month)) e.remove(k);
                    e.apply();
                    Toast.makeText(this, "Month cleared!", Toast.LENGTH_LONG).show();
                    loadAndShowAllData();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void resetEverything() {
        new AlertDialog.Builder(this)
                .setTitle("Start Fresh?").setMessage("Delete ALL data?")
                .setPositiveButton("Yes", (d, w) -> {
                    transPrefs.edit().clear().apply();
                    prefs.edit().clear().apply();
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                })
                .setNegativeButton("Cancel", null).show();
    }

    @SuppressLint("SetTextI18n")
    private void loadAndShowAllData() {
        float salary = prefs.getFloat("salary", 0f);
        String currency = prefs.getString("currency", "₩");
        float totalIncome = 0f, totalExpense = 0f;

        for (Object o : transPrefs.getAll().values()) {
            String[] p = o.toString().split("\\|");
            float amt = Float.parseFloat(p[0]);
            if (Boolean.parseBoolean(p[2])) totalIncome += amt;
            else totalExpense += amt;
        }

        float balance = salary + totalIncome - totalExpense;
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(0);

        tvSalary.setText("Salary: " + currency + " " + nf.format(salary));
        tvIncome.setText("Extra Income: " + currency + " " + nf.format(totalIncome));
        tvExpense.setText("Expense: " + currency + " " + nf.format(totalExpense));
        tvBalance.setText("Balance: " + currency + " " + nf.format(balance));
        tvBalance.setTextColor(balance >= 0 ? 0xFF00B894 : 0xFFE74C3C);
    }

    @Override protected void onResume() { super.onResume(); loadAndShowAllData(); }
}