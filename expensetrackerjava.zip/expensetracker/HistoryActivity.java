package com.example.expensetracker;

import android.os.Bundle;
import android.text.Html;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        loadHistory();
    }

    private void loadHistory() {
        ListView list = findViewById(R.id.listHistory);
        TextView empty = findViewById(R.id.tvEmpty);
        ArrayList<String> items = new ArrayList<>();

        Map<String, ?> all = getSharedPreferences("transactions", MODE_PRIVATE).getAll();
        TreeMap<String, String> sorted = new TreeMap<>(java.util.Collections.reverseOrder());
        sorted.putAll((Map<? extends String, ? extends String>) all);

        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(0);
        SimpleDateFormat out = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.ENGLISH);

        for (String val : sorted.values()) {
            String[] p = val.split("\\|", -1);
            if (p.length < 5) continue;
            float amt = Float.parseFloat(p[0]);
            String note = p[1];
            boolean inc = Boolean.parseBoolean(p[2]);
            String cat = p[3];
            String dateStr = p[4];

            try {
                SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH);
                String niceDate = out.format(parser.parse(dateStr));
                String sign = inc ? "+ " : "- ";
                String color = inc ? "#00B894" : "#E74C3C";
                items.add(String.valueOf(Html.fromHtml("<b><font color='" + color + "'>" + sign + nf.format(amt) + " ₩</font></b><br>"
                        + cat + " • " + note + "<br><small>" + niceDate + "</small>")));
            } catch (Exception e) { items.add("Error"); }
        }

        if (items.isEmpty()) {
            empty.setVisibility(TextView.VISIBLE);
            list.setVisibility(TextView.GONE);
        } else {
            empty.setVisibility(TextView.GONE);
            list.setVisibility(TextView.VISIBLE);
            list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items));
        }
    }

    @Override protected void onResume() { super.onResume(); loadHistory(); }
}