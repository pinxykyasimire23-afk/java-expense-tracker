package com.example.expensetracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private EditText etSalary;
    private Spinner spinnerCurrency;
    private SharedPreferences prefs;

    private final String[] currencyList = {
            "USD - US Dollar $",
            "EUR - Euro EUR",
            "GBP - British Pound GBP",
            "NGN - Nigerian Naira NGN",
            "GHS - Ghanaian Cedi GHS",
            "KES - Kenyan Shilling KSh",
            "UGX - Ugandan Shilling USh",
            "TZS - Tanzanian Shilling TSh",
            "ZAR - South African Rand R",
            "INR - Indian Rupee INR",
            "PKR - Pakistani Rupee PKR",
            "BDT - Bangladeshi Taka BDT",
            "LKR - Sri Lankan Rupee LKR",
            "IDR - Indonesian Rupiah Rp",
            "PHP - Philippine Peso PHP",
            "THB - Thai Baht THB",
            "VND - Vietnamese Dong VND",
            "MYR - Malaysian Ringgit RM",
            "SGD - Singapore Dollar S$",
            "KRW - Korean Won KRW",
            "JPY - Japanese Yen JPY",
            "CNY - Chinese Yuan CNY",
            "AED - UAE Dirham AED",
            "SAR - Saudi Riyal SAR"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSalary = findViewById(R.id.etSalary);
        spinnerCurrency = findViewById(R.id.spinnerCurrency);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnNext = findViewById(R.id.btnNext);

        prefs = getSharedPreferences("ExpenseTracker", MODE_PRIVATE);

        setupCurrencySpinner();
        loadSavedData();

        // Auto commas
        etSalary.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                etSalary.removeTextChangedListener(this);
                String clean = s.toString().replaceAll("\\D", "");
                if (!clean.isEmpty()) {
                    double parsed = Double.parseDouble(clean);
                    etSalary.setText(NumberFormat.getNumberInstance().format(parsed));
                    etSalary.setSelection(etSalary.getText().length());
                }
                etSalary.addTextChangedListener(this);
            }
        });

        btnSave.setOnClickListener(v -> saveSalary());
        btnNext.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, DashboardActivity.class)));
        btnNext.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClassName(getPackageName(), "com.example.expensetracker.DashboardActivity");
            startActivity(intent);
        });
    }

    private void setupCurrencySpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, currencyList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCurrency.setAdapter(adapter);
    }

    private void saveSalary() {
        String salaryStr = etSalary.getText().toString().replaceAll("\\D", "");
        if (salaryStr.isEmpty()) {
            Toast.makeText(this, "Enter salary!", Toast.LENGTH_SHORT).show();
            return;
        }
        float salary = Float.parseFloat(salaryStr);
        String fullText = spinnerCurrency.getSelectedItem().toString();
        String code = fullText.split(" - ")[0];

        prefs.edit()
                .putFloat("salary", salary)
                .putString("currency", code)
                .putString("currency_full", fullText)
                .apply();

        Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
    }

    private void loadSavedData() {
        float salary = prefs.getFloat("salary", 0f);
        if (salary > 0) {
            etSalary.setText(NumberFormat.getNumberInstance().format(salary));
        }
        String saved = prefs.getString("currency_full", "USD - US Dollar $");
        int pos = Arrays.asList(currencyList).indexOf(saved);
        if (pos >= 0) spinnerCurrency.setSelection(pos);
    }
}